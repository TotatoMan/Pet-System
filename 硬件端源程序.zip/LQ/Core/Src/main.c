/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
uint8_t RxBuff3[1];            //进入中断接收数据
uint8_t RxBuff1[1];
uint8_t Relay_8bit[3]={0x00};  //控制指令
uint8_t M702[17]={0};
int RxBuff3_count=0;
int RxBuff1_count=0;

float temperature=15.0,humidity=10.0;
int co2=0,ch2o=0,tvoc=0,pm25=0,pm10=0;

int fee_flag=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

void USART_printf (UART_HandleTypeDef *huart,char *fmt, ...){
    static char buffer[256];
    va_list args;
    va_start(args,fmt);
    vsprintf(buffer,fmt,args);
    va_end(args);
    HAL_UART_Transmit(huart,(uint8_t*)buffer,strlen(buffer),0xFFFFFFFFU);
}

//解析M702的数据
void parse_hex_data(uint8_t *M702)
{
	int i;
	uint8_t crc=0;
	for(i=0;i<16;i++) crc+=M702[i];
	crc%=256;
	if(crc==M702[16])
	{
		//解析数据
		co2=M702[2]*256+M702[3];

		ch2o=M702[4]*256+M702[5];

		tvoc=M702[6]*256+M702[7];

		pm25=M702[8]*256+M702[9];

		pm10=M702[10]*256+M702[11];

		//解析温度数据，参考文档可知：B13的bit7�?????1时温度为负，�?????0时温度为正，B13为温度的整数部分，B14为温度的小数部分
		int sign=1;
		if(M702[12]&0x40)sign=-1;
		temperature=sign*((M702[12]&0xbf)+M702[13]*0.1);

		humidity=((M702[14]&0xbf)+M702[15]*0.1);
	}

}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

	//串口1，接收指令
    if(huart->Instance == USART1)
    {

        //用Relay_8bit 接收串口传过来的十六进制数据
    	Relay_8bit[RxBuff1_count++]=RxBuff1[0];

    	//如果第二位数据不等于0x0d,说明数据不符合预设规范，重置计数
    	if(RxBuff1_count==2&&Relay_8bit[1]!=0x0d) RxBuff1_count=0;

    	//如果第三位数据不等于0x0a,说明数据不符合预设规范，重置计数
    	if(RxBuff1_count==3&&Relay_8bit[2]!=0x0a) RxBuff1_count=0;

    	//若RxBuff1_count==3说明前三位数据均有效，则进入判断，操作相应继电器
    	if(RxBuff1_count==3){
    		//判断是否打开风扇
			if(Relay_8bit[0]&0x01)  HAL_GPIO_WritePin(Fan_relay0_GPIO_Port, Fan_relay0_Pin, 1);
			else HAL_GPIO_WritePin(Fan_relay0_GPIO_Port, Fan_relay0_Pin, 0);
			//判断是否打开供暖
			if(Relay_8bit[0]&0x02)  HAL_GPIO_WritePin(Sun_relay1_GPIO_Port,Sun_relay1_Pin, 1);
			else HAL_GPIO_WritePin(Sun_relay1_GPIO_Port,Sun_relay1_Pin, 0);
			//判断是否打开喂食器
			if(Relay_8bit[0]&0x04)
			{
				fee_flag=1;
				HAL_GPIO_WritePin(Feed_relay2_GPIO_Port, Feed_relay2_Pin, 1);
			}
			else HAL_GPIO_WritePin(Feed_relay2_GPIO_Port, Feed_relay2_Pin, 0);
			//判断是否打开喷雾�??
			if(Relay_8bit[0]&0x08) HAL_GPIO_WritePin(Humidity_relay3_GPIO_Port, Humidity_relay3_Pin, 1);
			else  HAL_GPIO_WritePin(Humidity_relay3_GPIO_Port, Humidity_relay3_Pin, 0);

			//RxBuff1_count重新置零，等待下次读数据
			RxBuff1_count=0;
    	}

    	HAL_UART_Receive_IT(&huart1, (uint8_t *)RxBuff1, 1);
    }

    //串口3，接收测量数据
    if(huart->Instance == USART3)
    {
		//进入中断将数据接收到 M702数组，同时计数指针后移
		M702[RxBuff3_count++]=RxBuff3[0];
		//如果是判定为第一个字节的数据并且数据不是0x3c,说明未发现帧头1，计数重置
		if(RxBuff3_count==1&&M702[0]!=0x3c)RxBuff3_count=0;
		//如果是判定为第二个字节的数据并且数据不是0x02,说明发现帧头1，但未发现帧头2，计数重置
		if(RxBuff3_count==2&&M702[1]!=0x02)RxBuff3_count=0;
		//如果RxBuff3_count未被重置则表明数据帧头正确，且接收了17次，此时M702中存放的是采集的传感器HEX数据
		if(RxBuff3_count==17)
		{

			//解析hex数据
			parse_hex_data(M702);

			//当采集结束后重置RxBuff3_count变量，以便下次的接收判定
			RxBuff3_count=0;
		}
        //启动串口3
        HAL_UART_Receive_IT(&huart3, (uint8_t *)RxBuff3, 1);
    }

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart3, (uint8_t *)RxBuff3, 1); //打开串口3中断接收
  HAL_UART_Receive_IT(&huart1, (uint8_t *)RxBuff1, 1); //打开串口1中断接收
  HAL_TIM_Base_Start_IT(&htim6);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  //通过串口1，输出7位数据
	  USART_printf(&huart1,"%d,%d,%d,%d,%d,%.1f,%.1f\r\n",co2,ch2o,tvoc,pm25,pm10,temperature,humidity);
	  HAL_Delay(2000);

//	  HAL_GPIO_WritePin(Humidity_relay3_GPIO_Port, Humidity_relay3_Pin, 1);
//	  HAL_GPIO_WritePin(Fan_relay0_GPIO_Port, Fan_relay0_Pin, 1);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 8399;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 4999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Fan_relay0_Pin|Sun_relay1_Pin|Feed_relay2_Pin|Humidity_relay3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Fan_relay0_Pin Sun_relay1_Pin Feed_relay2_Pin Humidity_relay3_Pin */
  GPIO_InitStruct.Pin = Fan_relay0_Pin|Sun_relay1_Pin|Feed_relay2_Pin|Humidity_relay3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	static int fee_count=0;
	if(fee_flag&&++fee_count>=10)
	{
		fee_count=0;
		fee_flag=0;
		Relay_8bit[0]&=~0x04;
		HAL_GPIO_WritePin(Feed_relay2_GPIO_Port, Feed_relay2_Pin, 0);

	}

    if(htim==(&htim6))
    {
        /* 中断的程�??? */
    	//HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, 0);
    }

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
